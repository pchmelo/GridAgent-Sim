
Mercado de Energia
https://servicebus.ren.pt/datahubapi/electricity/ElectricityMarketPricesDaily?culture=pt-PT&date=2025-01-25


Produção
https://servicebus.ren.pt/datahubapi/electricity/ElectricityProductionBreakdownDaily?culture=pt-PT&date=2025-01-25

